import pandas as pd

df = pd.read_csv(
    "02_data/processed/clean_vendor_identity_logs.csv"
)

# Sort by timestamp
df = df.sort_values("timestamp")

# Focus on compromised activity
incidents = df[df["compromised"] == 1]

print("\nCompromised Activity Timeline")
print(incidents.head(20))

# Save report
incidents.to_csv(
    "08_outputs/incident_timeline.csv",
    index=False
)

print("\nIncident timeline saved.")