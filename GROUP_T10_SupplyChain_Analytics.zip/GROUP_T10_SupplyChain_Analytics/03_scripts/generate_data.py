import pandas as pd
import random
from datetime import datetime, timedelta

# =====================
# Vendor Identity Logs
# =====================

identity_logs = []

start_date = datetime(2026, 9, 1)

for i in range(5000):

    timestamp = start_date + timedelta(minutes=i)

    vendor_id = f"V{random.randint(1,100):03}"

    user_id = f"U{random.randint(1,500):03}"

    src_ip = f"192.168.{random.randint(1,255)}.{random.randint(1,255)}"

    auth_status = random.choice([
        "Success",
        "Failed"
    ])

    mfa_used = random.choice([
        "Yes",
        "No"
    ])

    failed_logins = random.randint(0, 15)

    request_count = random.randint(1, 500)

    bytes_sent = random.randint(100, 50000)

    compromised = 0

    if (
        failed_logins > 10
        or request_count > 400
        or bytes_sent > 40000
    ):
        compromised = 1

    identity_logs.append([
        timestamp,
        vendor_id,
        user_id,
        src_ip,
        auth_status,
        mfa_used,
        failed_logins,
        request_count,
        bytes_sent,
        compromised
    ])

# Add known malicious records

for i in range(50):

    timestamp = start_date + timedelta(
        minutes=6000 + i
    )

    vendor_id = "V999"

    user_id = "U999"

    src_ip = "255.255.255.255"

    auth_status = "Failed"

    mfa_used = "No"

    failed_logins = 15

    request_count = 500

    bytes_sent = 50000

    compromised = 1

    identity_logs.append([
        timestamp,
        vendor_id,
        user_id,
        src_ip,
        auth_status,
        mfa_used,
        failed_logins,
        request_count,
        bytes_sent,
        compromised
    ])

print("Identity Records:", len(identity_logs))

identity_df = pd.DataFrame(
    identity_logs,
    columns=[
        "timestamp",
        "vendor_id",
        "user_id",
        "src_ip",
        "auth_status",
        "mfa_used",
        "failed_logins",
        "request_count",
        "bytes_sent",
        "compromised"
    ]
)

identity_df.to_csv(
    "02_data/raw/vendor_identity_logs.csv",
    index=False
)


# =====================
# API Gateway Logs
# =====================

api_logs = []

endpoints = [
    "/shipments",
    "/inventory",
    "/orders",
    "/tracking",
    "/payments"
]

for i in range(10000):

    timestamp = start_date + timedelta(seconds=i)

    token_id = f"T{random.randint(1,500):04}"

    api_endpoint = random.choice(endpoints)

    response_code = random.choice([200, 200, 200, 404, 500])

    bytes_sent = random.randint(100, 10000)

    api_logs.append([
        timestamp,
        token_id,
        api_endpoint,
        response_code,
        bytes_sent
    ])

api_df = pd.DataFrame(
    api_logs,
    columns=[
        "timestamp",
        "token_id",
        "api_endpoint",
        "response_code",
        "bytes_sent"
    ]
)

api_df.to_csv(
    "02_data/raw/api_gateway_logs.csv",
    index=False
)

# =====================
# Network Traffic Logs
# =====================

network_logs = []

for i in range(20000):

    timestamp = start_date + timedelta(seconds=i)

    src_ip = f"10.0.{random.randint(1,255)}.{random.randint(1,255)}"

    dest_ip = f"172.16.{random.randint(1,255)}.{random.randint(1,255)}"

    port = random.choice([80, 443, 22, 3389])

    bytes_value = random.randint(500, 50000)

    protocol = random.choice(["TCP", "UDP"])

    network_logs.append([
        timestamp,
        src_ip,
        dest_ip,
        port,
        bytes_value,
        protocol
    ])

network_df = pd.DataFrame(
    network_logs,
    columns=[
        "timestamp",
        "src_ip",
        "dest_ip",
        "port",
        "bytes",
        "protocol"
    ]
)

network_df.to_csv(
    "02_data/raw/network_traffic_logs.csv",
    index=False
)

# =====================
# Helpdesk Tickets
# =====================

tickets = []

categories = [
    "Login Issue",
    "API Error",
    "Security Alert",
    "Access Request",
    "Account Lockout"
]

messages = [
    "Multiple failed logins detected",
    "Supplier unable to access portal",
    "Unexpected API activity observed",
    "Vendor token possibly compromised",
    "Suspicious access from unknown location"
]

for i in range(200):

    tickets.append([
        f"TKT{i+1:04}",
        f"V{random.randint(1,100):03}",
        random.choice(categories),
        random.choice(messages)
    ])

ticket_df = pd.DataFrame(
    tickets,
    columns=[
        "ticket_id",
        "vendor_id",
        "category",
        "description_text"
    ]
)

ticket_df.to_csv(
    "02_data/raw/helpdesk_tickets.csv",
    index=False
)

print("================================")
print("DATA GENERATION COMPLETE")
print("================================")
print("5000 Vendor Identity Logs")
print("10000 API Gateway Logs")
print("20000 Network Traffic Logs")
print("200 Helpdesk Tickets")
print("================================")

for i in range(50):

    timestamp = start_date + timedelta(minutes=6000+i)

    vendor_id = "V999"
    user_id = "U999"

    src_ip = "255.255.255.255"

    auth_status = "Failed"

    mfa_used = "No"

    failed_logins = 15

    request_count = 500

    bytes_sent = 50000

    compromised = 1

    identity_logs.append([
        timestamp,
        vendor_id,
        user_id,
        src_ip,
        auth_status,
        mfa_used,
        failed_logins,
        request_count,
        bytes_sent,
        compromised
    ])