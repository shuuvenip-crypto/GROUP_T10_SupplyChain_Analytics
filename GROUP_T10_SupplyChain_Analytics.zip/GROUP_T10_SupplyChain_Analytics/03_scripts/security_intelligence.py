import pandas as pd

# Load risk scores

df = pd.read_csv(
    "08_outputs/risk_scores.csv"
)

# High-risk vendors

high_risk = df[
    df["risk_level"] == "High Risk"
]

# Operational intelligence

operational_report = high_risk[
    [
        "vendor_id",
        "user_id",
        "risk_score",
        "risk_level"
    ]
]

# Executive summary

executive_summary = pd.DataFrame({
    "Metric": [
        "Total Records",
        "High Risk Records",
        "Medium Risk Records",
        "Low Risk Records"
    ],
    "Value": [
        len(df),
        len(df[df["risk_level"] == "High Risk"]),
        len(df[df["risk_level"] == "Medium Risk"]),
        len(df[df["risk_level"] == "Low Risk"])
    ]
})

# Save reports

operational_report.to_csv(
    "08_outputs/operational_intelligence.csv",
    index=False
)

executive_summary.to_csv(
    "08_outputs/executive_summary.csv",
    index=False
)

print("\nSECURITY INTELLIGENCE REPORT")

print("\nTop High-Risk Vendors")
print(operational_report.head(10))

print("\nExecutive Summary")
print(executive_summary)

print("\nReports Saved Successfully")