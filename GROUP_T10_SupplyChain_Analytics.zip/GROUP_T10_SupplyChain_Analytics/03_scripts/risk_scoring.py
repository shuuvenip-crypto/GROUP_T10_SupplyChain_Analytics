import pandas as pd

# =====================================
# LOAD DATA
# =====================================

df = pd.read_csv(
    "02_data/processed/clean_vendor_identity_logs.csv"
)

# =====================================
# CONVERT MFA VALUES
# =====================================

df["mfa_penalty"] = df["mfa_used"].apply(
    lambda x: 20 if x == "No" else 0
)

# =====================================
# CALCULATE RISK SCORE
# =====================================

df["risk_score"] = (
    (df["failed_logins"] * 3)
    +
    (df["request_count"] / 10)
    +
    (df["bytes_sent"] / 1000)
    +
    df["mfa_penalty"]
)

# Cap score at 100

df["risk_score"] = df["risk_score"].apply(
    lambda x: 100 if x > 100 else round(x, 2)
)

# =====================================
# RISK LEVELS
# =====================================

def risk_level(score):

    if score >= 70:
        return "High Risk"

    elif score >= 40:
        return "Medium Risk"

    else:
        return "Low Risk"

df["risk_level"] = df["risk_score"].apply(
    risk_level
)

# =====================================
# SORT BY RISK
# =====================================

ranked_vendors = df.sort_values(
    by="risk_score",
    ascending=False
)

# =====================================
# DISPLAY RESULTS
# =====================================

print("\nTOP 20 HIGHEST-RISK RECORDS")
print(
    ranked_vendors[
        [
            "vendor_id",
            "user_id",
            "failed_logins",
            "request_count",
            "bytes_sent",
            "risk_score",
            "risk_level"
        ]
    ].head(20)
)

print("\nRISK LEVEL DISTRIBUTION")
print(
    ranked_vendors["risk_level"].value_counts()
)

# =====================================
# SAVE OUTPUTS
# =====================================

ranked_vendors.to_csv(
    "08_outputs/risk_scores.csv",
    index=False
)

high_risk = ranked_vendors[
    ranked_vendors["risk_level"] == "High Risk"
]

high_risk.to_csv(
    "08_outputs/high_risk_vendors.csv",
    index=False
)

summary = pd.DataFrame({
    "Risk_Level":
    ranked_vendors["risk_level"]
    .value_counts()
    .index,

    "Count":
    ranked_vendors["risk_level"]
    .value_counts()
    .values
})

summary.to_csv(
    "08_outputs/risk_summary.csv",
    index=False
)

print("\n===================================")
print("RISK SCORING COMPLETE")
print("===================================")
print("Files saved:")
print("08_outputs/risk_scores.csv")
print("08_outputs/high_risk_vendors.csv")
print("08_outputs/risk_summary.csv")
print("===================================")