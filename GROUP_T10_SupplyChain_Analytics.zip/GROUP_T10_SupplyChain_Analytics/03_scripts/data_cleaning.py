import pandas as pd

files = [
    "vendor_identity_logs.csv",
    "api_gateway_logs.csv",
    "network_traffic_logs.csv",
    "helpdesk_tickets.csv"
]

for file in files:

    df = pd.read_csv(
        f"02_data/raw/{file}"
    )

    df.drop_duplicates(inplace=True)

    df.dropna(inplace=True)

    output_name = "clean_" + file

    df.to_csv(
        f"02_data/processed/{output_name}",
        index=False
    )

    print(f"Cleaned {file}")

print("All datasets cleaned!")
