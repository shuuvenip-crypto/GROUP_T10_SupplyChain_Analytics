import pandas as pd

# Load cleaned dataset
df = pd.read_csv(
    "02_data/processed/clean_vendor_identity_logs.csv"
)

print("\nDataset Preview")
print(df.head())

print("\nAuthentication Results")
print(df["auth_status"].value_counts())

print("\nMFA Usage")
print(df["mfa_used"].value_counts())

print("\nCompromised Accounts")
print(df["compromised"].value_counts())


import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(
    "02_data/processed/clean_vendor_identity_logs.csv"
)

print("\nDataset Preview")
print(df.head())

print("\nAuthentication Results")
print(df["auth_status"].value_counts())

print("\nMFA Usage")
print(df["mfa_used"].value_counts())

print("\nCompromised Accounts")
print(df["compromised"].value_counts())

# Create graph
auth_counts = df["auth_status"].value_counts()

auth_counts.plot(
    kind="bar",
    title="Authentication Results"
)

plt.savefig(
    "08_outputs/authentication_results.png"
)

plt.show()


plt.figure()

df["mfa_used"].value_counts().plot(
    kind="bar",
    title="MFA Usage"
)

plt.savefig("08_outputs/mfa_usage.png")
plt.show()

plt.figure()

df["compromised"].value_counts().plot(
    kind="bar",
    title="Compromised Accounts"
)

plt.savefig("08_outputs/compromised_accounts.png")
plt.show()

plt.figure()

df["vendor_id"].value_counts().head(10).plot(
    kind="bar",
    title="Top Active Vendors"
)

plt.savefig("08_outputs/top_vendors.png")
plt.show()