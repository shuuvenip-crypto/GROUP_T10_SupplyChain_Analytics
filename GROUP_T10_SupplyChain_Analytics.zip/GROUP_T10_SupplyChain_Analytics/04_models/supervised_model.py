import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

# Load cleaned dataset
df = pd.read_csv(
    "02_data/processed/clean_vendor_identity_logs.csv"
)

# Check class distribution
print("\nCompromised Distribution")
print(df["compromised"].value_counts())

# Convert text values
df["auth_status"] = df["auth_status"].map({
    "Success": 0,
    "Failed": 1
})

df["mfa_used"] = df["mfa_used"].map({
    "Yes": 1,
    "No": 0
})

# Features
X = df[
    [
        "auth_status",
        "mfa_used",
        "failed_logins",
        "request_count",
        "bytes_sent"
    ]
]

# Target
y = df["compromised"]

# Split data
X_train, X_test, y_train, y_test = train_test_split (
    X,
    y,
    test_size=0.3,
    random_state=42
)

# Build model
model = RandomForestClassifier(
    n_estimators=100,
    class_weight="balanced",
    random_state=42
)

# Train model
model.fit(X_train, y_train)

# Predict
predictions = model.predict(X_test)

# Results
print("\nConfusion Matrix")
print(confusion_matrix(y_test, predictions))

print("\nClassification Report")
print(classification_report(y_test, predictions))