import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# ==========================================
# LOAD DATA
# ==========================================

df = pd.read_csv(
    "02_data/processed/clean_vendor_identity_logs.csv"
)

# ==========================================
# CONVERT CATEGORICAL VALUES
# ==========================================

df["auth_status"] = df["auth_status"].map({
    "Success": 0,
    "Failed": 1
})

df["mfa_used"] = df["mfa_used"].map({
    "Yes": 1,
    "No": 0
})

# ==========================================
# FEATURES AND TARGET
# ==========================================

features = [
    "auth_status",
    "mfa_used",
    "failed_logins",
    "request_count",
    "bytes_sent"
]

target = "compromised"

X = df[features]
y = df[target]

# ==========================================
# TRAIN / TEST SPLIT
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.3,
    random_state=42
)

# ==========================================
# BASELINE MODEL
# ==========================================

model = RandomForestClassifier(
    n_estimators=100,
    class_weight="balanced",
    random_state=42
)

model.fit(X_train, y_train)

baseline_predictions = model.predict(X_test)

baseline_accuracy = accuracy_score(
    y_test,
    baseline_predictions
)

print("\n================================")
print("BASELINE MODEL")
print("================================")
print("Accuracy:", round(baseline_accuracy, 4))

# ==========================================
# TEST 1 - EVASION ATTACK
# ==========================================

evasion_data = X_test.copy()

evasion_data["failed_logins"] = (
    evasion_data["failed_logins"] * 0.2
)

evasion_data["request_count"] = (
    evasion_data["request_count"] * 0.3
)

evasion_data["bytes_sent"] = (
    evasion_data["bytes_sent"] * 0.3
)

evasion_predictions = model.predict(
    evasion_data
)

evasion_accuracy = accuracy_score(
    y_test,
    evasion_predictions
)

print("\n================================")
print("TEST 1 : EVASION ATTACK")
print("================================")
print("Accuracy:", round(evasion_accuracy, 4))

# ==========================================
# TEST 2 - DATA POISONING
# ==========================================

poisoned_y_train = y_train.copy()

poison_count = int(
    len(poisoned_y_train) * 0.10
)

poisoned_y_train.iloc[:poison_count] = (
    1 - poisoned_y_train.iloc[:poison_count]
)

poisoned_model = RandomForestClassifier(
    n_estimators=100,
    class_weight="balanced",
    random_state=42
)

poisoned_model.fit(
    X_train,
    poisoned_y_train
)

poison_predictions = poisoned_model.predict(
    X_test
)

poison_accuracy = accuracy_score(
    y_test,
    poison_predictions
)

print("\n================================")
print("TEST 2 : DATA POISONING")
print("================================")
print("Accuracy:", round(poison_accuracy, 4))

# ==========================================
# TEST 3 - FEATURE MANIPULATION
# ==========================================

feature_manipulation = X_test.copy()

feature_manipulation["mfa_used"] = 1

feature_predictions = model.predict(
    feature_manipulation
)

feature_accuracy = accuracy_score(
    y_test,
    feature_predictions
)

print("\n================================")
print("TEST 3 : FEATURE MANIPULATION")
print("================================")
print("Accuracy:", round(feature_accuracy, 4))

# ==========================================
# SUMMARY RESULTS
# ==========================================

summary = pd.DataFrame({
    "Scenario": [
        "Baseline",
        "Evasion Attack",
        "Data Poisoning",
        "Feature Manipulation"
    ],
    "Accuracy": [
        baseline_accuracy,
        evasion_accuracy,
        poison_accuracy,
        feature_accuracy
    ]
})

# ==========================================
# SAVE RESULTS
# ==========================================

summary.to_csv(
    "08_outputs/adversarial_test_results.csv",
    index=False
)

print("\n================================")
print("ADVERSARIAL TESTING COMPLETE")
print("================================")
print(summary)

print("\nResults saved:")
print(
    "08_outputs/adversarial_test_results.csv"
)

print("================================")