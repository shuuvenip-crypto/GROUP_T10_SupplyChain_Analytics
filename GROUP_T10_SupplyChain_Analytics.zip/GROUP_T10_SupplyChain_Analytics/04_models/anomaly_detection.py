import pandas as pd
from sklearn.ensemble import IsolationForest

# Load dataset
df = pd.read_csv(
    "02_data/processed/clean_vendor_identity_logs.csv"
)

# Convert values
df["auth_status"] = df["auth_status"].map({
    "Success": 0,
    "Failed": 1
})

df["mfa_used"] = df["mfa_used"].map({
    "Yes": 1,
    "No": 0
})

# Features
X = df[
    [
        "auth_status",
        "mfa_used",
        "failed_logins",
        "request_count",
        "bytes_sent"
    ]
]

# Build Isolation Forest
model = IsolationForest(
    contamination=0.05,
    random_state=42
)

# Detect anomalies
df["anomaly"] = model.fit_predict(X)

print("\nAnomaly Distribution")
print(df["anomaly"].value_counts())

# Extract anomalies
anomalies = df[df["anomaly"] == -1]

print("\nTotal Records:", len(df))
print("Total Anomalies Found:", len(anomalies))

print("\nFirst 10 Anomalies")
print(anomalies.head(10))

# Save anomalies
anomalies.to_csv(
    "08_outputs/anomalies_detected.csv",
    index=False
)

print("\nResults saved successfully!")