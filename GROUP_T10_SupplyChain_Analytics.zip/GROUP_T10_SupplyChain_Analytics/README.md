# T10 Logistics and Supply Chain Third-Party Compromise Analytics

Capstone project starter structure.
