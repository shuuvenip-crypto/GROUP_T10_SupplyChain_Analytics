import pandas as pd
from collections import Counter
import re

# =====================================
# LOAD DATA
# =====================================

df = pd.read_csv(
    "02_data/raw/helpdesk_tickets.csv"
)

print("\nDataset Preview:")
print(df.head())

# =====================================
# TEXT CLEANING
# =====================================

df["clean_text"] = (
    df["description_text"]
    .str.lower()
)

# Remove punctuation
df["clean_text"] = df["clean_text"].apply(
    lambda x: re.sub(r"[^a-zA-Z0-9 ]", "", x)
)

# =====================================
# STOP WORDS
# =====================================

stop_words = {
    "the", "and", "is", "to",
    "of", "a", "in", "on",
    "for", "from", "with"
}

# =====================================
# TOKENIZATION
# =====================================

all_words = []

for text in df["clean_text"]:

    words = text.split()

    words = [
        word for word in words
        if word not in stop_words
    ]

    all_words.extend(words)

# =====================================
# MOST COMMON WORDS
# =====================================

word_counts = Counter(all_words)

print("\nTop 10 Keywords:")
print(word_counts.most_common(10))

# =====================================
# SECURITY KEYWORDS
# =====================================

security_keywords = [
    "failed",
    "logins",
    "suspicious",
    "compromised",
    "access",
    "token",
    "unknown",
    "alert"
]

def detect_security_terms(text):

    found = []

    for keyword in security_keywords:

        if keyword in text:
            found.append(keyword)

    return ", ".join(found)

df["security_indicators"] = df["clean_text"].apply(
    detect_security_terms
)

# =====================================
# HIGH RISK TICKETS
# =====================================

df["risk_level"] = df["security_indicators"].apply(
    lambda x: "High Risk"
    if x != ""
    else "Low Risk"
)

high_risk = df[
    df["risk_level"] == "High Risk"
]

print("\nHigh Risk Tickets:")
print(high_risk.head(10))

# =====================================
# CATEGORY ANALYSIS
# =====================================

print("\nTicket Categories:")
print(df["category"].value_counts())

# =====================================
# SAVE OUTPUTS
# =====================================

df.to_csv(
    "08_outputs/nlp_results.csv",
    index=False
)

high_risk.to_csv(
    "08_outputs/high_risk_tickets.csv",
    index=False
)

print("\n===================================")
print("NLP ANALYSIS COMPLETE")
print("===================================")
print("Results saved to:")
print("08_outputs/nlp_results.csv")
print("08_outputs/high_risk_tickets.csv")
print("===================================")
