import pandas as pd
import random

# Number of simulation runs
runs = 1000

results = []

for i in range(runs):

    # Current environment
    baseline_risk = random.uniform(60, 90)

    # MFA reduces risk
    mfa_risk = baseline_risk * random.uniform(
        0.60,
        0.80
    )

    # API rate limiting
    api_risk = baseline_risk * random.uniform(
        0.50,
        0.70
    )

    # Zero Trust
    zero_trust_risk = baseline_risk * random.uniform(
        0.30,
        0.50
    )

    results.append([
        baseline_risk,
        mfa_risk,
        api_risk,
        zero_trust_risk
    ])

df = pd.DataFrame(
    results,
    columns=[
        "Baseline",
        "MFA",
        "API_Rate_Limiting",
        "Zero_Trust"
    ]
)

print("\nAverage Risk Scores")
print(df.mean())

# Save full results

df.to_csv(
    "08_outputs/simulation_results.csv",
    index=False
)

summary = pd.DataFrame({
    "Scenario": df.columns,
    "Average_Risk": df.mean().values
})

summary.to_csv(
    "08_outputs/simulation_summary.csv",
    index=False
)

print("\nSimulation Complete")
print(
    "Results saved to 08_outputs/"
)
