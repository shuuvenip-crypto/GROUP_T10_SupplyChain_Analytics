import streamlit as st
import pandas as pd

# ==================================================
# PAGE CONFIG
# ==================================================

st.set_page_config(
    page_title="Shuuveni & Eli cc Security Analytics Dashboard",
    layout="wide"
)

st.title(
    "Shuuveni & Eli cc Security Analytics Dashboard"
)

st.markdown(
    "Third-Party Compromise Detection Decision Support System"
)

# ==================================================
# LOAD FILES
# ==================================================

risk_df = pd.read_csv(
    "08_outputs/risk_scores.csv"
)

anomaly_df = pd.read_csv(
    "08_outputs/anomalies_detected.csv"
)

timeline_df = pd.read_csv(
    "08_outputs/incident_timeline.csv"
)

nlp_df = pd.read_csv(
    "08_outputs/high_risk_tickets.csv"
)

simulation_df = pd.read_csv(
    "08_outputs/simulation_summary.csv"
)

intel_df = pd.read_csv(
    "08_outputs/executive_summary.csv"
)

adv_df = pd.read_csv(
    "08_outputs/adversarial_test_results.csv"
)

# ==================================================
# DASHBOARD METRICS
# ==================================================

st.header("Security Overview")

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "Total Records",
    len(risk_df)
)

col2.metric(
    "High Risk",
    len(
        risk_df[
            risk_df["risk_level"] == "High Risk"
        ]
    )
)

col3.metric(
    "Medium Risk",
    len(
        risk_df[
            risk_df["risk_level"] == "Medium Risk"
        ]
    )
)

col4.metric(
    "Anomalies Found",
    len(anomaly_df)
)

# ==================================================
# RISK SCORES
# ==================================================

st.header("Risk Scoring")

st.write(
    "Highest-risk vendor activities detected."
)

st.dataframe(
    risk_df.head(20)
)

# ==================================================
# ANOMALY DETECTION
# ==================================================

st.header("Anomaly Detection")

st.write(
    f"Total anomalies detected: {len(anomaly_df)}"
)

st.dataframe(
    anomaly_df.head(20)
)

# ==================================================
# INCIDENT TIMELINE
# ==================================================

st.header("Incident Timeline")

st.write(
    "Chronological compromised activity."
)

st.dataframe(
    timeline_df.head(20)
)

# ==================================================
# NLP ANALYSIS
# ==================================================

st.header("NLP Analysis")

st.write(
    "High-risk helpdesk tickets identified."
)

st.dataframe(
    nlp_df.head(20)
)

# ==================================================
# SIMULATION RESULTS
# ==================================================

st.header("Monte Carlo Simulation")

st.write(
    "Comparison of security controls."
)

st.dataframe(
    simulation_df
)

# ==================================================
# SECURITY INTELLIGENCE
# ==================================================

st.header("Security Intelligence")

st.write(
    "Executive Summary"
)

st.dataframe(
    intel_df
)

# ==================================================
# ADVERSARIAL TESTING
# ==================================================

st.header("Adversarial Testing")

st.write(
    "Model robustness evaluation."
)

st.dataframe(
    adv_df
)

# ==================================================
# FINAL RECOMMENDATION
# ==================================================

st.header("Analyst Recommendation")

st.success(
    """
    Recommended Actions

    • Investigate high-risk vendors immediately.
    • Review anomalous activities identified by Isolation Forest.
    • Enforce MFA across all vendor accounts.
    • Apply API rate limiting.
    • Implement Zero Trust Segmentation.
    • Monitor vendors identified in Security Intelligence reports.
    """
)

# ==================================================
# FOOTER
# ==================================================

st.info(
    "SAS821S Capstone Project - Logistics and Supply Chain Third-Party Compromise Analytics"
)